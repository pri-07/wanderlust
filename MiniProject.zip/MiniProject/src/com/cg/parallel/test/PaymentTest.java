package com.cg.parallel.test;

public class PaymentTest {

}
