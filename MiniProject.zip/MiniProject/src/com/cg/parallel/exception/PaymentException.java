package com.cg.parallel.exception;

public class PaymentException extends Exception{

}
