package com.cg.parallel.service;

import com.cg.parallel.dto.Payment;

public interface PaymentService {
	
	public String addDetails(Payment payment);

}
