package com.cg.parallel.dao;

import com.cg.parallel.dto.Payment;

public interface PaymentDAO {
	
	public String addDetails(Payment payment);

}
