package myPackage8;

import java.util.*;

public class Factorial {
	static int n;
	public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number");
	n=sc.nextInt();
	sc.close();
	if (n==0)
	{
     System.out.println(1);
	}
	else
		{
			System.out.println((factorial(n)));
		}
	
 
	}
  	static int factorial(int n)
   	{
  		int fact=1,i;
   		for(i=1;i<=n;i++)
   		{
   			fact=fact*i;
   		}
   		return fact;
  	
   	}
}
