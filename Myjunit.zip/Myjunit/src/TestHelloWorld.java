import org.junit.Test; 
import static org.junit.Assert.*;
public class TestHelloWorld { 
    @Test
      public void testSay() 
        {   
            HelloWorld hi = new HelloWorld(); 
            assertEquals("Hello World!", hi.say());
        } } 
class  HelloWorld{
    String say(){ 
            return "Hello World!" ;
            		}
}
