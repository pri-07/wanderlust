package com.cg.mobshop.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;
import com.cg.mobshop.exception.PurchaseException;

public class PurchaseDAOImpl implements PurchaseDAO
{
	
	EntityManager manager;
	
	public PurchaseDAOImpl() throws PurchaseException, IOException
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		manager=emf.createEntityManager();
	}
	
	@Override
	public int addPurchaseDetails(PurchaseDetails pr) throws SQLException 
	{
		manager.getTransaction().begin();
		manager.persist(pr);
		manager.getTransaction().commit();
		return pr.getPurchaseId();
	}	
	@Override
	public List<Mobile> getMobileList() {
		List<Mobile> list=new ArrayList<>();
		
		TypedQuery<Mobile> qry=manager.createQuery("select p from Mobile p",Mobile.class); //Mobile is entity class name  //select all recors from mobile table
		
		list= qry.getResultList();
		return list;
		

	}

	@Override
	public List<Mobile> getMobileList(double min, double max) throws SQLException {
	
		TypedQuery<Mobile> qry=manager.createQuery("select p from Mobile p where p.price between :lower and :upper " , Mobile.class); //Mobile class
		
		qry.setParameter("lower", min);
		qry.setParameter("upper", max);
		
		List<Mobile> list=qry.getResultList();
		return list;
	}

	@Override
	public Mobile updateMobileDetails(Mobile mob) throws SQLException, PurchaseException {
		
		manager.getTransaction().begin();
		
		Mobile mobile=manager.find(Mobile.class, mob.getMobileID());
		mobile.setPrice(mob.getPrice());
		mobile.setQuantity(mob.getQuantity());
		manager.merge(mobile);
		
		manager.getTransaction().commit();
		return mob;
		
	}

}
