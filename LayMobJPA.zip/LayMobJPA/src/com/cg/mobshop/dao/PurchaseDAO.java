package com.cg.mobshop.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;
import com.cg.mobshop.exception.PurchaseException;

public interface PurchaseDAO 
{
	public int addPurchaseDetails(PurchaseDetails pr) throws SQLException;
	public List<Mobile> getMobileList() throws SQLException;
	public List<Mobile> getMobileList(double min,double max) throws SQLException;
	public Mobile updateMobileDetails(Mobile mob) throws SQLException, PurchaseException;
}
