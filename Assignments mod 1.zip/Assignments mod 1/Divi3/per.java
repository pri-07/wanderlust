import java.util.*;
class per{
	public static void main(String args[])
	{String name;
	 float age;
	 Scanner s=new Scanner(System.in); 
	
		System.out.println("Enter name");
		name=s.nextLine();
		System.out.println("Enter age");
		age=s.nextFloat();
		try {
		if(age<15)
			throw new PersonExcep();  
	
		
		}
	catch(PersonExcep e)
		{
		System.out.println(e);
		
		}
	}
}