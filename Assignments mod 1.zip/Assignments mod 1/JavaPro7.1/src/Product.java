import java.util.*;
import java.util.Arrays;

public class Product {
	String pro[]=new String[5];
Scanner sc=new Scanner(System.in);
	public static void main(String args[])
       {
	        Product p=new Product();
	   }
	Product()
	{
		System.out.println("Enter product names");
		for(int i=0;i<5;i++)
		{
			pro[i]=sc.nextLine();
		}
		Arrays.sort(pro);
		for(int i=0;i<5;i++)
		{
			System.out.println("Product["+i+"]"+pro[i]);
		}
	
	}


}
