import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TestFileReadLineDEmo {

		public static void main(String args[])
		{
		File myFile=new File("C://Divisha//FileIO//src//TestEmployeeREadDEmo.java");
		FileReader fr=null;
		FileWriter fw=null;
		
		BufferedReader br=null;
		BufferedWriter bw=null;
		
	try {
		fr=new FileReader(myFile);
		fw=new FileWriter("MyFile.txt");
		
		br=new BufferedReader(fr);
		bw=new BufferedWriter(fw);
		
		String line=br.readLine();
		while(line!=null)
		{
			System.out.print(line);
			bw.write(line);
			bw.flush();
			line=br.readLine();
		}
	}
	catch(IOException e)
	{
		e.printStackTrace();
	
	}
	}}


