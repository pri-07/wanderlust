import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;
import java.util.Iterator;


public class TestPropertyFileDemo {
	public static void main(String ags[])
	{FileInputStream fis=null;
	Properties myPros=null;
		try {
			 fis=new FileInputStream("UserInfo.properties");
		myPros=new Properties();
		myPros.load(fis);
		String unm=myPros.getProperty("userid");
		String pwd=myPros.getProperty("password");
		System.out.println("Credentials"+unm+":  "+pwd);
		System.out.println("************");
	    Set<Object> ks=myPros.keySet();
		Iterator it=ks.iterator();
		
		while(it.hasNext())
		{
			System.out.println(":"+it.next());
		}
		
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
}
