import java.io.*;
import java.util.*;

public class TestPropsWriteDemo {
public static void main(String args[])
{FileOutputStream fos=null;
Properties myDbInfo=null;

	try {
		 fos=new FileOutputStream("dnIno.properties");
		 myDbInfo=new Properties();
		 myDbInfo.setProperty("dbUser" ,"System");
		 myDbInfo.setProperty("dbPwd" ,"Root");
		 myDbInfo.store(fos,"This is database info");
		 System.out.println("Data written in file");
		 }
	
		 catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
}
