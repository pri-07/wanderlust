import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class TestSerializationDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id");
		int eid=sc.nextInt();
		System.out.println("Enter name");
		String enm=sc.next();
		System.out.println("Enter sal ");
		float esl=sc.nextFloat();
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		
		Employee e1=new Employee(eid,enm,esl);
		try {
		fos= new FileOutputStream("Empobj.obj");
		oos=new ObjectOutputStream(fos);
		oos.writeObject(e1);
		System.out.println("Employee written in file");
		
		}
catch(IOException e)
		{
	e.printStackTrace();
		}
	}

}
