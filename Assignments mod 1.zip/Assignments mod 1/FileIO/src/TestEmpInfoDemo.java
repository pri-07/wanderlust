import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class TestEmpInfoDemo {
	public static void main(String args[])
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id");
		int eid=sc.nextInt();
		System.out.println("Enter name");
		String enm=sc.next();
		System.out.println("Enter sal ");
		float esl=sc.nextFloat();
		FileOutputStream fos=null;
		DataOutputStream dos=null;
		try {
		fos=new FileOutputStream("EmpTnfo.txt");
		dos=new DataOutputStream(fos);
		dos.writeInt(eid);
	    dos.writeUTF(enm);
		dos.writeFloat(esl);
		System.out.println("All info written");
		}
		
	catch(IOException e)
		{
		e.printStackTrace();
		}
	}

}
