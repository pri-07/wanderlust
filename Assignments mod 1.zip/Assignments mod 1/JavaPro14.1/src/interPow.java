@FunctionalInterface
public interface interPow{
	public double funPow(double a,double b);
}
