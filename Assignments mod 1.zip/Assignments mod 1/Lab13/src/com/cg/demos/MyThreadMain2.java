package com.cg.demos;

public class MyThreadMain2 {
	public static void main(String args[]) {
	Thread thread=new Thread(new MyThread2());
	thread.start();
	for(int i=1;i<=10;i++)
	{
		System.out.println("Main Thread : i="+i);
	try {Thread.sleep(1000);
	}
	catch (InterruptedException e )
	{
		e.printStackTrace();
	}
	
	if(i==5)
	{try{
		Thread.currentThread().join();
	//it will pause current thread, main
	//thread will join after the thread running has completed its execution
	//current thread is static method
		}
	
	catch (InterruptedException e )
	{
		e.printStackTrace();
	}
	}
	
}
	}
}
/*synchronisation-is required when we do not want any resource to go in 
 * deadlock state. wait(), notify(),notifyAll() are methods of object class not 
 * Thread class. some part of a method can be synchronized by using synchronised 
 * keyword.
 * Only one thread at a time can acquire lock pool.*/ 
