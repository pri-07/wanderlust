		package com.cg.sunch.demos;
		
		public class Producer extends Thread
	{
			private Resource rc;
			public Producer (Resource rc)
			{
				this.rc=rc;
			}
		@Override
		public void run()
		{
			for(int i=1;i<=20;i++) 
		   {
			int val =(int)(Math.random()*100);
			rc.insert(val);
			
			try 
			  {
		     	Thread.sleep(1000);
			  }
			catch(InterruptedException e)
			  {
				e.printStackTrace();
			  }
			}
			
		}
	}
