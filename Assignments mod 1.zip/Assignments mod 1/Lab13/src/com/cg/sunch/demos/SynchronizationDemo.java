package com.cg.sunch.demos;

public class SynchronizationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Resource resource=new Resource();
	Producer producer=new Producer(resource);
	Consumer consumer=new Consumer(resource);
	producer.start();
	consumer.start();
	}

}
