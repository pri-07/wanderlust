import java.util.Scanner;

public class Employee implements Comparable <Employee>{
	long id;
	String name,desig;
	float sal;
	String insuranceScheme;
	Scanner sc=new Scanner(System.in);
public Employee(long id,String name,float sal,String desig)
{
this.id=id;
this.name=name;
this.sal=sal;
this.desig=desig;
if(desig.equals("analyst")&&sal>10000)
	insuranceScheme="A";
else
	insuranceScheme="B";
	}	
@Override
public void display()
{System.out.println("ID"+id);
System.out.println("Name"+name);
System.out.println("Salary"+sal);
System.out.println("Designation"+desig);
System.out.println("Insurance Scheme "+insuranceScheme);
System.out.println	}
public int compareTo(Employee ee) {
	if(ee.sal>this.sal)
		return 1;
	else if(ee.sal==this.sal)
		return 0;
	else
		return -1;
}}