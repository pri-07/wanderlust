import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.text.html.HTMLDocument.Iterator;

public class EmpInfo {
	
	public static void main(String args[]) {
		
	Scanner sc=new Scanner(System.in);
	HashMap<Long,Employee> directory=new HashMap<Long,Employee>();
	System.out.println("Enter number of employees");
	int n=sc.nextInt();
	
	for(int i=0;i<n;i++)
	{
	long id;
	String name,desig;
	float sal;
	System.out.println("Enter employee details");
	
	    System.out.println("Enter employee Id");
		id=sc.nextInt();
	    System.out.println("Enter employee Name");
		name=sc.next();
	    System.out.println("Enter employee Salary");
		sal=sc.nextFloat();
	    System.out.println("Enter employee designation");
		desig=sc.next();
		Employee e=new Employee(id, name, sal, desig);
		directory.put(id,e);
	}
	
	System.out.println("Sort entries according to salary");
	
	
	Collection<Employee> vset=directory.values();
	Iterator<Employee> empit=vset.iterator();
ArrayList<Employee> emplist =new ArrayList();
Iterator it=emplist.iterator();
	while(it.hasNext())
	{
		emplist=it.add(empit);
	}
	Collections.sort(emplist);
	
			
    System.out.println("Enter ID of employee you want to remove");
    int del_id=sc.nextInt();
    	directory.remove(del_id);
    
	
	}
	
	
	
}
