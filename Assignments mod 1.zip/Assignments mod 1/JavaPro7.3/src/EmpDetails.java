import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
public class EmpDetails {
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	HashMap<Long,Emp> directory=new HashMap<Long,String>();
	System.out.println("Enter number of employees");
	int n=sc.nextInt;
	System.out.println("Enter employee details");
	for(int i=0;i<n;i++)
	directory.put();
	System.out.println(directory);
	System.out.println("Print ENTREIS");
	Set<Map.Entry<Long,String>> mapSet=directory.entrySet();
	Iterator<Map.Entry<Long,String>> it=mapSet.iterator();
	while(it.hasNext())
	{Map.Entry<Long,String> entry =it.next();
	System.out.println("Key  "+entry.getKey()+ "  Name  "+entry.getValue());
	}
	
	}
}
