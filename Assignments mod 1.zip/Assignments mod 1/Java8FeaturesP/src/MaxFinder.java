@FunctionalInterface
public interface MaxFinder {
public int max(int a,int b);
}
