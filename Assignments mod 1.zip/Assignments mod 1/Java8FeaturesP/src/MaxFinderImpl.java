
public class MaxFinderImpl implements MaxFinder {
	@Override
	public int max(int a,int b)
	{
		return((a>b)?a:b);
		}
	}

