	import java.sql.Connection;
	import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
import java.util.Scanner;

public class TestEmpSelectDemo2 {
public static void main(String args[])
{

		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter min sal");
		int minSal=sc.nextInt();
		System.out.println("Enter max sal");
		int maxSal=sc.nextInt();
		
		String qry="SELECT * from emp_157507 where emp_sal>=? and emp_sal<=?";//paramatrized query

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection
					("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g",
							"lab1btrg5","lab1boracle");
			pst=con.prepareStatement(qry);
			pst.setInt(1,minSal);
			pst.setInt(2,maxSal);
		
			rs=pst.executeQuery();
			while(rs.next()) {
			System.out.println(":"+rs.getInt("emp_id")+":"+rs.getString("emp_name")+":"+rs.getInt("emp_sal"));
		} }

		catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		}
	}

