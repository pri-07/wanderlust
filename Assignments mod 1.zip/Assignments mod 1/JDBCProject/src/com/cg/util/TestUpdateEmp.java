package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestUpdateEmp {
	public static void main(String args[])
	{
	Connection con=null;
	PreparedStatement pst=null;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter id of Employee to update");
	int empId=sc.nextInt();
	System.out.println("Enter sal of Employee to update");
	int empSal=sc.nextInt();
	
	String updateQry="UPDATE emp_157507 SET emp_sal=? WHERE emp_id=? ";
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection
				("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g",
						"lab1btrg5","lab1boracle");    
	
		pst=con.prepareStatement(updateQry);
		pst.setInt(2,empId);
		pst.setInt(1,empSal);
		int noOfQueriesAffected=pst.executeUpdate();
		
		System.out.print("Record updated"+noOfQueriesAffected);
		
	}
	
	catch (ClassNotFoundException e) {

		e.printStackTrace();
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	}
}
