package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestDeleteEmp {
	public static void main(String args[])
	{
	Connection con=null;
	PreparedStatement pst=null;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter id");
	int empId=sc.nextInt();
	String deleteQry="DELETE FROM emp_157507 WHERE emp_id=?";
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection
				("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g",
						"lab1btrg5","lab1boracle");    
	
		pst=con.prepareStatement(deleteQry);
		pst.setInt(1,empId);
		int noOfQueriesAffected=pst.executeUpdate();
		
		System.out.print("Record deleted"+noOfQueriesAffected);
		
	}
	
	catch (ClassNotFoundException e) {

		e.printStackTrace();
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	}

}
