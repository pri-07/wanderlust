package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpInsertDemo {
	public static void main(String args[])
	{Connection con=null;
	PreparedStatement pst=null;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter id");
	int empId=sc.nextInt();
	System.out.println("Enter name");
	String empName=sc.next();
	System.out.println("Enter sal");
	int empSal=sc.nextInt();
	
	String insertQry="Insert into emp_157507 values(?,?,?)";
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection
				("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g",
						"lab1btrg5","lab1boracle");    
	
		pst=con.prepareStatement(insertQry);
		pst.setInt(1,empId);
		pst.setString(2,empName);
		pst.setInt(3,empSal);
		int data=pst.executeUpdate();
		System.out.print("Record inserted"+data);
		
	}
	
	catch (ClassNotFoundException e) {

		e.printStackTrace();
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	}

}
