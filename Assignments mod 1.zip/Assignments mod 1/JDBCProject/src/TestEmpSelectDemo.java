import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestEmpSelectDemo
{
	public static void main(String args[])
	{Connection con=null;
	Statement st=null;
	ResultSet rs=null;

	try {

		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection
				("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g",
						"lab1btrg5","lab1boracle");
		st=con.createStatement();
		rs=st.executeQuery("SELECT * from emp_157507 where emp_sal>3000");
		while(rs.next()) {
		System.out.println(":"+rs.getInt("emp_id")+":"+rs.getString("emp_name")+":"+rs.getInt("emp_sal"));
	} 
		}

	catch (ClassNotFoundException e) {

		e.printStackTrace();
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	}
}
