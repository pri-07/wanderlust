import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Rev {
	public static void main(String args[]) {
		int i;
		FileInputStream fp;
		try {
		fp=new FileInputStream("C://Divisha//JavaPro8.2//src//numb.txt");
		while((i=fp.read())!=-1)
		{
			if(i%2==0)
				System.out.println("Even"+i);
		}
	}
catch(IOException e){e.printStackTrace();}
{
	}
}}
