import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class number {

	public static void main(String args[])
	{FileReader fr=null;
	Scanner br=null;
		try {
			 fr=new FileReader("C://Divisha//JavaPro8.2//src//numb.txt");
			 br=new Scanner(fr);
			 //ArrayList<Character> al=new ArrayList<Character>();
			String ln=br.nextLine();
			String arr[]=ln.split(",");
			for(String a:arr){			
				
				int n=Integer.parseInt(a);
				if(n%2==0)
					System.out.println("Even"+n);
			}
				}
		catch(IOException e)
		{
			e.printStackTrace();
		}
			 
	
}}
