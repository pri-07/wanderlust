
public interface interSpace {
	String findSpace(String str) ;

}
