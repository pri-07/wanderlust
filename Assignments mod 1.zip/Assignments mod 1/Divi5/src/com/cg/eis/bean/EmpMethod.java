package com.cg.eis.bean;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;



public class EmpMethod {
	
	void inputFile(Employee e2)

	{
	FileOutputStream fos=null;
	ObjectOutputStream oos=null;
		try {
			fos= new FileOutputStream("EmployeeDetails.txt",true);
			oos=new ObjectOutputStream(fos);
			oos.writeObject(e2);
			
			System.out.println("Employee written in file");
			
			}
	catch(IOException e)
			{
		e.printStackTrace();
			}
		}
	void outFile()
	{
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try {
			
			 fis=new  FileInputStream("EmployeeDetails.txt");
			 ois=new		ObjectInputStream(fis);
			 Employee ee=(Employee)ois.readObject();
			 System.out.println("Emp info from file "+ee.id+":"+ee.name+":"+ee.salary+":"+ee.desig);
			 
		} catch (ClassNotFoundException | IOException e) {
			
			
			e.printStackTrace();
		}
	}
	}


