package com.cg.mps.exception;


public class CustomerException extends Exception{

String msg;
public CustomerException(String msg)
{
	super(msg);
	this.msg=msg;
}


}


