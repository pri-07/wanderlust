	package com.cg.mps.service;
	
	import java.util.ArrayList;
	import java.util.regex.Pattern;
	
	import com.cg.mps.dao.CustDao;
	import com.cg.mps.dao.CustDaoImpl;
	import com.cg.mps.dto.Customer;
	import com.cg.mps.dto.Mobile;
	import com.cg.mps.exception.CustomerException;
	
	public class CustServiceImpl implements CustService{
		CustDao custDao=null;
		public CustServiceImpl()
		{
			custDao=new CustDaoImpl();
		}
	
		public ArrayList<Mobile> getAllMob() throws CustomerException
		{
			return custDao.getAllMob();
		}
		
		public int addCust(Customer ee) throws CustomerException
		{
			return custDao.addCust(ee);
		}
		
		@Override
		public int deleteMob(int mid) throws CustomerException {
			// TODO Auto-generated method stub
			return custDao.deleteMob(mid);
		}
	
		public ArrayList<Mobile> searchMob(float p1,float p2) throws CustomerException {
			// TODO Auto-generated method stub
			return custDao.searchMob(p1,p2);
		}
		//validate cnmane
		public boolean validateCustname(String cname_nm) throws CustomerException
		{
			String namePattern="[A-Z][a-z]+";
			if(Pattern.matches(namePattern, cname_nm)&&cname_nm.length()<20)
		        return true;
	
			else
			 {
				throw new CustomerException
				("Invalid Customer Name should start with capital"
				+"and not more than 20 characters");
				
			 }
		}
		public boolean validateMailid(String mailid_mid) throws CustomerException{
			String mailPattern="[a-z]+@[a-z]+.com";
			if(Pattern.matches(mailPattern, mailid_mid))
		        return true;
	
			else
			 {
				throw new CustomerException
				("Invalid Mial ID");
				
			 }
		}
		public boolean validatePhoneno(String phoneno_pno) throws CustomerException{
			String phnPattern="[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]";
			if(Pattern.matches(phnPattern, phoneno_pno))
		        return true;
	
			else
			 {
				throw new CustomerException
				("Invalid phone no");
				
			 }
		}
		public boolean validateMobileid(int mobileid_mobid) throws CustomerException{
			String mobidPattern="[0-9][0-9][0-9][0-9]";
			String mobid=Integer.toString(mobileid_mobid);
			if(Pattern.matches(mobidPattern, mobid))
		        return true;
	
			else
			 {
				throw new CustomerException
				("Invalid Mobile ID");
				
			 }
		}
	}
