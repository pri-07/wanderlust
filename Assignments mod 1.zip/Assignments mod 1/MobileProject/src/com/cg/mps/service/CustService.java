package com.cg.mps.service;

import java.util.ArrayList;

import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;

public interface CustService 
{
	public ArrayList<Mobile> getAllMob() throws CustomerException;
	public int deleteMob(int mid) throws CustomerException;
	public int addCust(Customer ee) throws CustomerException;
	public ArrayList<Mobile> searchMob(float p1,float p2) throws CustomerException;
	public boolean validateCustname(String cname_nm) throws CustomerException;
	public boolean validateMailid(String mailid_mid) throws CustomerException;
	public boolean validatePhoneno(String phoneno_pno) throws CustomerException;
	public boolean validateMobileid(int mobileid_mobid) throws CustomerException;
}