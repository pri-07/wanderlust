		package com.cg.mps.ui;
		
		import java.sql.Date;
	import java.time.LocalDate;
	import java.time.format.DateTimeFormatter;
	import java.util.ArrayList;
	import java.util.Iterator;
	import java.util.Random;
	import java.util.Scanner;
	
	import org.apache.log4j.Logger;
	import org.apache.log4j.PropertyConfigurator;
	
	import com.cg.mps.dto.Customer;
		import com.cg.mps.dto.Mobile;
		import com.cg.mps.exception.CustomerException;
		import com.cg.mps.service.CustService;
		import com.cg.mps.service.CustServiceImpl;
		
		public class TestCustDemoclient {
		
		static CustServiceImpl custservice=null;
		static Scanner sc=null;
			public static void main(String args[])
		{
				TestCustDemoclient t=new TestCustDemoclient();
		custservice=new CustServiceImpl();
				sc=new Scanner(System.in);
				
				
	
				System.out.println("Welcome to mobile management system");
				System.out.println("Enter choice");
				System.out.println("1.  Buy Mobile  2.  search mobile acc to price "
						+ "3  Display all mob details "
						+ "4  Delete mobile details");
				int n=sc.nextInt();
		switch(n) {
		case 1:		
		t.insertCust();
		break;
		case 2:
		t.searchPhone();
		break;
		case 3:
		t.dispAllMob();
		break;
		case 4:
			delMob();
			break;
		default:
			System.out.println("Wrong input");
		}	
		}
				
				
				
			private static void insertCust() {
				 int purchaseid_id=0;
				 String cname_nm=null;
				 String mailid_mid=null;
				 String phoneno_pno=null;
				 int mobileid_mobid=0;
				 Date purchasedate_pdate = null;
				 
			try {
				Scanner sc=new Scanner(System.in);
			Random rand=new Random();
			 purchaseid_id=rand.nextInt();
				 
				System.out.println("Enter cname");
				cname_nm=sc.next();
				{
					if(custservice.validateCustname(cname_nm))
					{
						System.out.println("Enter mailid");
						mailid_mid=sc.next();
						{
							if(custservice.validateMailid(mailid_mid))
							{
								System.out.println("Enter phoneno");
								phoneno_pno=sc.next();
								if(custservice.validatePhoneno(phoneno_pno))
								{
									System.out.println("Enter mobileid");
									mobileid_mobid=sc.nextInt();
									{
										if(custservice.validateMobileid(mobileid_mobid))
		                                       {
		                                    	LocalDate ld=LocalDate.now();
		                               			purchasedate_pdate=Date.valueOf(ld);
		                                       }
		                                else
		                                        System.out.println("Enter mobileid");
		                                    	   
									}	}
									else
										System.out.println("Enter valid phoneno");
								}
							
							else
								System.out.println("Enter mailid properly");
						}
					}
					else
						System.out.println("Enter name properly");
				}
				
				
		
			Customer e1=new Customer(purchaseid_id,cname_nm,mailid_mid,phoneno_pno,purchasedate_pdate,mobileid_mobid);
					int dataInserted=custservice.addCust(e1);
					if(dataInserted==1)
					{
						System.out.println("Data of customer inserted");
					}
					else
					
						System.out.println("Data not inserted");
							
					
				}
			catch(CustomerException e)
			{
				e.printStackTrace();
			}
		}
			private static void searchPhone()
			{float p1,p2;
			ArrayList<Mobile> mob=null;
			
		System.out.println("Enter min and max range of mobile you want to buy");
				p1=sc.nextFloat();
				p2=sc.nextFloat();
				 try {
					mob=custservice.searchMob(p1,p2);
					System.out.println("Search done");
					for(Mobile m:mob)
					{
						System.out.println(m.getMobileid()+m.getName()+m.getPrice()+m.getQuantity());
					}
				} catch (CustomerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			private static void dispAllMob()
			{
				ArrayList<Mobile> mob=null;
				try {
					mob=custservice.getAllMob();
					System.out.println("All mobile details done");
					for(Mobile m:mob)
					{
	System.out.println(m.getMobileid()+"  "+m.getName()+"  "+m.getPrice()+"  "+m.getQuantity());
					}
				} catch (CustomerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
			private static void delMob()
			{
				int mid,data;
				try 
				{
					System.out.println("Enter mobile id to delete");
					mid=sc.nextInt();
					data=custservice.deleteMob(mid);
					System.out.println(" Deleted mobile details"+data);
				}
				catch (CustomerException e) 
				{
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
				
			}
		
		}
