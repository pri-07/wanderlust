				           package com.cg.mps.dao;
							
							import java.io.IOException;
							import java.sql.Connection;
							import java.sql.PreparedStatement;
							import java.sql.ResultSet;
							import java.sql.SQLException;
							import java.sql.Statement;
							import java.util.ArrayList;
							import org.apache.log4j.Logger;
							
							import org.apache.log4j.PropertyConfigurator;

                           import com.cg.mps.dto.Customer;
							import com.cg.mps.dto.Mobile;
							import com.cg.mps.exception.CustomerException;
							import com.cg.mps.util.dbutil;
							
							
							public class CustDaoImpl implements CustDao {
							static Logger myLogger=Logger.getLogger(CustDaoImpl.class);
							
							Connection con=null;
							Statement st=null;
							PreparedStatement pst=null;
							ResultSet rs=null;
							public CustDaoImpl()
							{
								
							PropertyConfigurator.configure("log4j.properties");
							}
							
							
							
							@Override
							
							//display all mobile details
							public ArrayList<Mobile> getAllMob() throws CustomerException{
								ArrayList<Mobile> mobList=null;
								try{ 
									mobList=new ArrayList<Mobile>(); 
									con=dbutil.getConn();
								String selectqry1="SELECT * from mobile";
								st=con.createStatement();
								rs=st.executeQuery(selectqry1);
								while(rs.next())
									{
									mobList.add(new Mobile(rs.getInt("mobileid"),rs.getString
									("name"),rs.getInt("price"),rs.getInt("quantity")));
									
									}}
								catch(SQLException e)
								{e.printStackTrace();
								
									throw new CustomerException(e.getMessage());
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								return mobList;}
							
							
							
							
							
							//delete mob details according to id
							
							public int deleteMob(int mid) throws CustomerException{
								//ArrayList<Mobile> mobList=null;
								int a=0;
								try{ 
										con=dbutil.getConn();
										String selectqry4="DELETE FROM mobile WHERE mobileid = ?";
										pst=con.prepareStatement(selectqry4);
										pst.setInt(1,mid);
										a=pst.executeUpdate();
										System.out.print(a+"Rows Deleted");
									
										myLogger.info("Details Deleted ");}
								catch(Exception e)
								{
									e.printStackTrace();
									myLogger.error("Details Deleted ");
									throw new CustomerException("Not Deleted");
								} 
								finally 
								{
									try 
									{
										pst.close();
										con.close();
									}
									catch(SQLException e)
									{
										//e.printStackTrace();
							
										throw new CustomerException(e.getMessage());
									}
								}
							//daoLogger.info("All data retreived"+empList);
							return a;	
							
						}
							
							
							
							
							@Override
							//add customer
							public int addCust(Customer ee) throws CustomerException
							{
								PropertyConfigurator.configure("log4j.properties");
							int data=0;
							ArrayList<Mobile> mobList=null;
							try {
								
								con=dbutil.getConn();
								String selectqry2="SELECT quantity from mobile where mobileid=?";
								pst=con.prepareStatement(selectqry2);
								pst.setInt(1,ee.getMobileid());
								rs=pst.executeQuery();
								int q=0;
								
								while(rs.next()) {q=rs.getInt("quantity");}
								if(q>0)
								{
								
							String insertqry="INSERT into purchasedetail values(?,?,?,?,?,?)";
							pst=con.prepareStatement(insertqry);
							pst.setInt(1,ee.getPurchaseid());
							pst.setString(2,ee.getCname());  
							pst.setString(3,ee.getMailid());
							pst.setString(4,ee.getPhoneno());
							pst.setDate(5,ee.getPurchasedate());
							pst.setInt(6,ee.getMobileid());
							
							data=pst.executeUpdate();
						System.out.println("************Customer details added************");
							
							
						///update mobile details after 
							String selectqry3="UPDATE mobile set quantity=? where mobileid=?";
							pst=con.prepareStatement(selectqry3);
							 q=q-1;
							pst.setInt(1,q);
							pst.setInt(2,ee.getMobileid());
							data=pst.executeUpdate();
							int mob_pur=ee.getMobileid();
							//Mobile details after purchase
						System.out.println("*********Mobile details after purchase*********");
						    	
							mobList=new ArrayList<Mobile>(); 
							con=dbutil.getConn();
							String selectqry6="SELECT * from mobile where mobileid=?";
							pst=con.prepareStatement(selectqry6);
							pst.setInt(1,mob_pur);
							rs=pst.executeQuery();
							while(rs.next())
								{
								mobList.add(new Mobile(rs.getInt("mobileid"),rs.getString
								("name"),rs.getInt("price"),rs.getInt("quantity")));
								System.out.println("Mobile purchased is of id"+rs.getInt("mobileid"));
								}
							     
								}else
		
									throw new CustomerException("Mobile not available");
						
								myLogger.info("Purchase details inserted"+ee);}
							catch(Exception e)
							{
								myLogger.error("Data not insrted");
							throw new CustomerException(e.getMessage());
							
								}
							finally
							{try {
								pst.close();
								con.close();}
							catch(Exception e) {
								e.printStackTrace();
								throw new CustomerException(e.getMessage());}
							}
							
							return data;}
							
							
							
							
							@Override
							//search mobile on price 
							public ArrayList<Mobile> searchMob(float p1,float p2) throws CustomerException
							{
								ArrayList<Mobile> mobList=null;
								try {
							mobList=new ArrayList<Mobile>(); 
							con=dbutil.getConn();
									
									//String selectqry5="SELECT * from mobile where price<=p1 and price>=p2";
							         String selectqry5="SELECT * from mobile where price>? and price<?";
							
						            pst=con.prepareStatement(selectqry5);
									pst.setFloat(1,p1);
									pst.setFloat(2,p2);
									rs=pst.executeQuery();
									while(rs.next())
									{
									mobList.add(new Mobile(rs.getInt("mobileid"),rs.getString
									("name"),rs.getInt("price"),rs.getInt("quantity")));
									}		
										
									myLogger.info("Search details ");
							         }
								catch(Exception e)
								{e.printStackTrace();
								myLogger.error("Data not fetched");
								throw new CustomerException(e.getMessage());
									}
								return mobList;
							}
						
						
						
						
							
		}
							