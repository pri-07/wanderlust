package com.cg.mps.dao;

import java.util.ArrayList;

import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;

public interface CustDao {
	public ArrayList<Mobile> getAllMob() throws CustomerException;
	public int deleteMob(int mid) throws CustomerException;
	public int addCust(Customer ee) throws CustomerException;
	public ArrayList<Mobile> searchMob(float p1,float p2) throws CustomerException;
	
	
}
