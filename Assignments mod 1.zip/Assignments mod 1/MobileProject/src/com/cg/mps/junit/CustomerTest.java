package com.cg.mps.junit;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.service.CustServiceImpl;
import com.cg.mps.ui.TestCustDemoclient;


public class CustomerTest {
static CustServiceImpl client=null;
static Customer a=null;

@BeforeClass
public static void setUp()
{ 
	LocalDate ld=LocalDate.now();
	Date pdate = Date.valueOf(ld);
	a=new Customer(1001,"Ankit","ankit@shr.com","7896541230",pdate,1001);
	client=new CustServiceImpl ();
	ArrayList<Mobile> a=new ArrayList();
	a.add(new Mobile(1001,"Nokia Lumina 520",8000,20));
	
	System.out.print("Setup is call" +"Before the execution of "+"all test cases");
	}
@AfterClass
public static void tearDown()
{System.out.print("tearDown is call once\" +\"Before the execution of \"+\"each test cases");
	}
@Before
public void init()
{System.out.print("init is call once\" +\"Before the execution of \"+\"each test cases");
	}
@After
public void destroy()
{System.out.print("destroy is call once\" +\"after the execution of \"+\"each test cases");
	}
@Test
public void test1() throws CustomerException
{
	Assert.assertEquals(1,client.addCust(a));
	}
public void test2() throws CustomerException
{
	Assert.assertEquals(1,client.deleteMob(1001));
	}
public void test3() throws CustomerException
{
	Assert.assertEquals(a,client.searchMob(8000,50000));
	}
/*@Test
public void testDivide2()
{
	Assert.assertEquals(20,calc.divide(5));
	}

@Test
public void testDivide3()
{
	Assert.assertEquals(1,calc.divide(0));
	}*/
}



