
public class AccountMain {
	public static void main(String args[])
	{
	Person p=new Person("Smith",20);
	Person p1=new Person("Katthy",20);
	Account a=new Account(2000,p);
	Account b=new Account(3000,p1);
	}}
