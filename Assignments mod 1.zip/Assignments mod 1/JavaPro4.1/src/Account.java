import java.util.Random;
import java.util.Scanner;

public class Account {
	
	static long accNum=0;
	static double balance;
	Person accHolder;
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}

	 void withdraw(int out)
	 {
		 
	 }
void deposit(int in) {
	this.balance=this.balance+in;
}

public static void main(String args[])
{
	accNum=(long) (Math.random()*100);
	Account a=new Account();

	SavingAcc s=new SavingAcc();
	Person p1=new Person();
	p1.name="Smith";
	a.balance=2000;
	s.deposit(2000);
	System.out.println("Name  "+p1.name+"Account no  "+a.accNum+"Balance  "+a.balance);
	Account a1=new Account();
	Person p2=new Person();
	accNum=(long) (Math.random()*100);
	p2.name="Kathy";
	a.balance=3000;
	s.withdraw(2000);
	System.out.println("Name  "+p2.name+" Account no  "+a1.accNum+" Balance  "+a1.balance);
	}

Account(){
	balance=500;
	
	
	}







}
