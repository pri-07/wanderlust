
public class CurrentAcc extends Account {
int overDraftLimit;
CurrentAcc()
{
	if(overDraftLimit>5000)
		withdraw(1);

}
void withdraw(int n) {
	if(n==1)
		System.out.println("Overdraft limit reached");
}
}