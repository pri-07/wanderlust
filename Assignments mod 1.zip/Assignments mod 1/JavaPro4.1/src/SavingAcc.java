
public class SavingAcc extends Account
{final double minBal=500;

SavingAcc(){}

void withdraw(int out)
		{if(balance>minBal)
			balance=balance-out;
		else
			 System.out.print("Cannot be withdrawn");
		}
void deposit(int in) {
		balance=balance+in;
}
}

