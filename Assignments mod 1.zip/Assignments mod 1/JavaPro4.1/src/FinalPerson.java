
public class FinalPerson {
String name;
float age;
FinalPerson(){}
FinalPerson(String n, float b)
{
	name=n;
	age=b;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getAge() {
	return age;
}
public void setAge(float age) {
	this.age = age;
}

}
