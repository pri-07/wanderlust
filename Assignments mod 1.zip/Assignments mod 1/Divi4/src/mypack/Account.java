package mypack;
import java.util.*;
class Account
{   
	long accNo;
	double balance;
	Person accHolder;
	void deposit()
	{
		
	}
	void withdraw()
	{
		
	}
	double getBalance();
public static void main(String args[])
{
	Account a=new Account();
	
}

Account(){
S	
}



}
