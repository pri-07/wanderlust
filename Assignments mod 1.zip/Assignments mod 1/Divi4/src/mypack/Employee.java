package mypack;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;
import java.io.*;

public class Employee implements Serializable
{ int id;
String name;
float salary;
String desig;
	public Employee(int id, String name, float salary, String desig) {
		
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.desig = desig;
}

	public static void main(String args[])
	{
	int id;
	String name;
	float salary;
	String desig;
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter id");
	    id=sc.nextInt();
		System.out.println("Enter name");
		name=sc.next();
		System.out.println("Salary");;
		salary=sc.nextFloat();
		System.out.println("Designation");;
		desig=sc.next();
		try {
			if(salary<3000)
				throw new EmployeeException();
			Employee e1=new Employee(id,name,salary,desig);
			e1.inputFile(e1);
			
			
		    }
	catch(EmployeeException a)
		{
		System.out.println(a);
		}
		
	
	
	
	}

void inputFile(Employee e2)

{
FileOutputStream fos=null;
ObjectOutputStream oos=null;
	try {
		fos= new FileOutputStream("C://Divisha//Divi4//he//emp.txt");
		oos=new ObjectOutputStream(fos);
		oos.writeObject(e2);
		
		System.out.println("Employee written in file");
		
		}
catch(IOException e)
		{
	e.printStackTrace();
		}
	}


}