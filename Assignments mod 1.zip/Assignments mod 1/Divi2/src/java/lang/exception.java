package java.lang;

public class exception {

}
