
public class Person {
String firstName;
String lastName;
String gender;
long phno;
Person()
{

}
Person(String firstName, String lastName, String gender,long phno)
{
this.firstName=firstName;
this.lastName=lastName;
this.gender=gender;
this.phno=phno;
}

public void setFirstName(String firstName)
{   
	this.firstName=firstName;
}

public void setLastName(String lastName)
{
	this.lastName=lastName;
}
public void setGender(String gender)
{
	this.gender=gender;
}
public void setphno(long phno)
{
	this.phno=phno;
}

public String getFirstName(String firstName)
{
	return firstName;
}
public String getLastName(String lastName)
{
	return lastName;
}
public String getGender(String gender)
{
	return gender;
}
public long getphno(long phno)
{
	return phno;
}

public void disp()
{
	System.out.println("First name"+firstName);
	System.out.println("Last name"+lastName);
	System.out.println("Gender"+gender);}

}
