package java.lang;

public enum Gender {
	M,F

}
