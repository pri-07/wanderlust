import java.util.Scanner;

public class PersonMain{
	public static void main(String args[])
{

	String a,b;
	//Gender g=Gender.F;
String m="F";
	long pno;
	
	Scanner s=new Scanner(System.in);
	
	try
	{
		System.out.println("Enter first name");
		a=s.nextLine();
		System.out.println("Enter last name");
		b=s.nextLine();
				if(a.length()==0||b.length()==0)
			throw new MyExcep ();
				
				int flag=0;
		while(flag!=1) {
		System.out.println("Enter Gender");
		m=s.next();
		
		if(m==(Gender.F).toString() ||m==(Gender.M).toString()) {
		 flag=1;
		 
			}
			else 
				System.out.println("Wrong input");
			
		
		}
		
		System.out.println("Enter pno");
		pno=s.nextLong();
		Person p=new Person(a,b,m,pno);
	}
	catch(MyExcep e)
	{
		System.out.println(e);
	}
	finally
	{
		s.close();
	}
	
}
	
	
	
	
	
	
}