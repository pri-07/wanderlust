	import java.util.*;
	import java.util.ArrayList;
	

public class ArrayListPro {


public static void main(String args[])
	       {
Scanner	sc = new Scanner(System.in);		
		
			System.out.println("Enter no of products");
			int n=sc.nextInt();
			ArrayList<String> al=new ArrayList<String>();
			System.out.println("Enter product names");
			for(int i=0;i<n;i++)
			{
	        al.add(sc.next());			
			}
			al.sort(null);
			for(String s:al)
			{
				System.out.println(s);
			}
		
	

	}
}
