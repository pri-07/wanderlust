package com.cg.eis.exception;

public class EmployeeException extends Exception{

	@Override
	public String toString() {
		return ("Less Salary input");
	}
	

}
