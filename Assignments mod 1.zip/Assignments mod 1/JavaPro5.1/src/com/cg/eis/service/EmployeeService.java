package com.cg.eis.service;

public interface EmployeeService {
public char insrSch(String desig,String sal);
}
