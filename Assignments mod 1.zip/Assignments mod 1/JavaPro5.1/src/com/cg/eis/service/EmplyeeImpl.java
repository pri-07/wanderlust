package com.cg.eis.service;
import com.cg.eis.pl.UserClass;

public class EmplyeeImpl implements EmployeeService {
	
	public char insrSch(String desig,String sal)
	{
		
	}
}
