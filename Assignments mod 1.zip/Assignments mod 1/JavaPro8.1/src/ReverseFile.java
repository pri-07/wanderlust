import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class ReverseFile {
public static void main(String args[])
{
	FileReader fr=null;
	FileWriter fw=null;
	BufferedReader br=null;
	BufferedWriter bw=null;
	try {
	fr=new FileReader("C://Divisha//FileIO//MyFile.txt");
	 br=new BufferedReader(fr);
	fw =new FileWriter("Reverse.txt");
	 bw=new BufferedWriter(fw);
	 ArrayList<Character> al=new ArrayList<Character>();
	int ln=br.read();
//char arr[]=new arr[50];
//int j=0;
	 while(ln!=-1)
	{
		al.add((char)ln);
		//arr[j]=br.readLine();
	//j++;
		ln=br.read();
	}
	int l=al.size();
	for(int i=l-1;i>=0;i--)
	{
		bw.write(al.get(i).toString());
		bw.flush();
	}
	
	}
	catch(IOException e)
	{
		e.printStackTrace();;
		
	}

}
}
