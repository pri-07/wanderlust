import java.util.Scanner;

public class PositiveString {

	public static void main(String[] args) {
		PositiveString p=new PositiveString();
		p.Check();
		
                                            }

	void Check()
	{int j,k,f=0;
	
	String str;
	Scanner in=new Scanner (System.in);
	System.out.println("Enter a string");
	str=in.nextLine();
		char charr[]=str.toCharArray() ;
		int l=charr.length;
		for(int i=0;i<l;i++)
		{
			j=(int)charr[i];
			k=(int)charr[i+1];
			if(k>j)
			{
				
			}
			else {System.out.println("Not Positive");
				break;}
		}
	
	
	
	
	}
}
