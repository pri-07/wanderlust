
public class Person {
String firstName;
String lastName;
String gender,fnm;
long phno;
int yrs;

Person()
{

}
Person(String firstName, String lastName, String gender,long phno,int yrs)
{
this.firstName=firstName;
this.lastName=lastName;
this.gender=gender;
this.phno=phno;
this.yrs=yrs;
}

public void setFirstName(String firstName)
{   
	this.firstName=firstName;
}

public void setLastName(String lastName)
{
	this.lastName=lastName;
}
public void setGender(String gender)
{
	this.gender=gender;
}
public void setphno(long phno)
{
	this.phno=phno;
}
public void setbday(int yrs)
{
	this.yrs=yrs;
}

public String getFirstName()
{
	return firstName;
}
public String getLastName()
{
	return lastName;
}
public String getGender()
{
	return this.gender;
}
public long getphno()
{
	return this.phno;
}
public int getyrs()
{
	return yrs;
}

public void disp()
{
	System.out.println("First name"+firstName);
	System.out.println("Last name"+lastName);
	System.out.println("Gender"+gender);
	System.out.println("Bday"+yrs);
	
}
void getFullName()
{
	fnm=firstName+lastName;
System.out.println("Full name is"+fnm);
}


}
