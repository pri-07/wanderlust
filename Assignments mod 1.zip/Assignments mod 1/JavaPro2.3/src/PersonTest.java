import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class PersonTest {
static	Person p=null;
@BeforeClass
public static void setUp()
{
	p=new Person("Divisha","Agarwal","F",123456789,15);
	System.out.print("Setup is call" +"Before the execution of "+"all test cases");
	}
@AfterClass
public static void tearDown()
{System.out.print("tearDown is call once\" +\"Before the execution of \"+\"each test cases");
	}
@Before
public void init()
{System.out.print("init is call once\" +\"Before the execution of \"+\"each test cases");
	}
@After
public void destroy()
{System.out.print("destroy is call once\" +\"after the execution of \"+\"each test cases");
	}
@Test
public void testDivide1()
{
	Assert.assertEquals("Divisha",p.getFirstName());
	}
@Test
public void testDivide2()
{
	Assert.assertEquals("Agarwal",p.getLastName());
	}

@Test
public void testDivide3()
{
	Assert.assertEquals("F",p.getGender());
	}
public void testDivide4()
{
	Assert.assertEquals(123456789,p.getphno());
	}
public void testDivide5()
{
	Assert.assertEquals(15,p.getyrs());
	}
}



