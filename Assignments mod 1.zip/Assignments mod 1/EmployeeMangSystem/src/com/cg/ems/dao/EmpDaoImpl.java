package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DButil;


public class EmpDaoImpl implements EmpDao {
Logger daoLogger=null;
	Connection con=null;
Statement st=null;
PreparedStatement pst=null;
ResultSet rs=null;
public EmpDaoImpl()
{
Logger myLogger=Logger.getLogger(EmpDaoImpl.class);
	PropertyConfigurator.configure("log4j.properties");
}

public ArrayList<Employee> getAllEmp() throws EmployeeException{
	ArrayList<Employee> empList=null;
	try{ 
		empList=new ArrayList<Employee>(); 
		con=DButil.getConn();
	String selectqry="SELECT * from emp_157507";
	st=con.createStatement();
	rs=st.executeQuery(selectqry);
	while(rs.next())
		{
		empList.add(new Employee(rs.getInt("emp_id"),rs.getString
				("emp_name"),rs.getFloat("emp_sal")));
		
		}}
	catch(SQLException e)
	{e.printStackTrace();
	
		throw new EmployeeException(e.getMessage());
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	finally {
try {
	st.close();
	rs.close();
	con.close();
}
catch(SQLException e)
{e.printStackTrace();
daoLogger.error(e.getMessage());
throw new EmployeeException(e.getMessage());
}
	
	}
daoLogger.info("All data retreived"+empList);
	return empList;	

}
@Override
public int addEmp(Employee ee) throws EmployeeException
{
	int data;
	try {con=DButil.getConn();
String insertqry="INSERT into emp_157507 values(?,?,?)";
pst=con.prepareStatement(insertqry);
pst.setInt(1,ee.getEmpId());
pst.setString(2,ee.getEmpnmae());
pst.setFloat(3,ee.getEmpSal());
data=pst.executeUpdate();
}
catch(Exception e)
{e.printStackTrace();

throw new EmployeeException(e.getMessage());
	}
return data;
}
}
