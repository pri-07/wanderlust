package com.cg.ems.dto;

public class Employee {
private int empId;
private String empnmae;
private float empSal;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpnmae() {
	return empnmae;
}
public void setEmpnmae(String empnmae) {
	this.empnmae = empnmae;
}
public float getEmpSal() {
	return empSal;
}
public void setEmpSal(float empSal) {
	this.empSal = empSal;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", empnmae=" + empnmae + ", empSal=" + empSal + "]";
}
public Employee(int empId, String empnmae, float empSal) {
	super();
	this.empId = empId;
	this.empnmae = empnmae;
	this.empSal = empSal;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}

}
