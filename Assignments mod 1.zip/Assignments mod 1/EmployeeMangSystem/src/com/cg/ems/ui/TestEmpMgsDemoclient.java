package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

public class TestEmpMgsDemoclient {
static EmpService empservice=null;
	public static void main(String args[])
{
		Scanner sc=new Scanner(System.in);
		empservice=new EmpServiceImpl();
		System.out.println("Welcome to employee MS");
int choice=0;
while(true)
{
	System.out.println("What do u want to do??");
	System.out.println("\t1:Add Emp \t2:Show all "
	+ "emp\t3.Update emp\t4:Delete emp\t5:Exit");
	System.out.println("Enter choice");
	choice=sc.nextInt();
	switch(choice)
	{
	case 1:insertEmp();
	break;
	case 2:dispAllEmp();
	break;
	default:System.exit(0);
	
	}
	}
	
	}
	private static void dispAllEmp() {
		ArrayList<Employee>empList;
		try {
		empList=empservice.getAllEmp();
		System.out.println("\t EmpId \tEmpNm \tEmpSal");
		for(Employee ee:empList)
		{
			System.out.println("\t"+ee.getEmpId()+"\t"+ee.getEmpnmae()+"\t"+ee.getEmpSal());
		}}
	
	catch(EmployeeException e) {
		e.printStackTrace();}
		
		}
	private static void insertEmp() {
		
	try {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id");
		int eId=sc.nextInt();
		System.out.println("Enter name");
		String enm=sc.next();
		float esal=0.0F;
		if(empservice.validateEmpname(enm))
		{
			System.out.println("Enter sal");
			esal=sc.nextFloat();
			Employee e1=new Employee(eId,enm,esal);
			int dataInserted=empservice.addEmp(e1);
			if(dataInserted==1)
			{
				dispAllEmp();
			}
			else
			
				System.out.println("Data not inserted");
					
			
		}}
		
	
	catch(EmployeeException e)
	{
		e.printStackTrace();
	}
}}
