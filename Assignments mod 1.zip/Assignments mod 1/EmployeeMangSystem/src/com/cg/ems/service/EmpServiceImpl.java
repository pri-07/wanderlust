package com.cg.ems.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.ems.dao.EmpDao;
import com.cg.ems.dao.EmpDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public class EmpServiceImpl implements EmpService{
	EmpDao empDao=null;
	public EmpServiceImpl()
	{
		empDao=new EmpDaoImpl();
	}

	public ArrayList<Employee> getAllEmp() throws EmployeeException
	{
		return empDao.getAllEmp();
	}
	
	public int addEmp(Employee ee) throws EmployeeException
	{
		return empDao.addEmp(ee);
	}
	public boolean validateEmpname(String eName) throws EmployeeException
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, eName))
		{
			return true;
}
	
	
		else
		{
			throw new EmployeeException
			("Invalid Empl Name shouls start with capital"
			+"Only characters allowed");
			
		}
	}
	
}
