public class Emp implements Comparable<Emp>  {
int empId;
String empName;
float empSal;                                               
public Emp() {}
public String toString()
{
	return (empName);

}

public Emp(int empId, String empName, float empSal) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empSal = empSal;
} 

@Override// to check that if the values returned by has set are unique
public boolean equals(Object obj)
{
	Emp ee=(Emp)obj;
	if(this.empId==ee.empId)
		{return true;
		}
	else
		return false;
}
@Override

public int hashCode()
{
	return empId;}

public int compareTo(Emp ee)
{
	
	return ((this.empName).compareTo(ee.empName));
}



}