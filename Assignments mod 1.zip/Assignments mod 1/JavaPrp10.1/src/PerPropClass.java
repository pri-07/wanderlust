import java.io.*;
import java.util.*;

public class PerPropClass {
public static void main(String args[])
{
FileOutputStream fos=null;
Properties myDbInfo=null;
FileInputStream fis=null;
Scanner in=new Scanner(System.in);
String uid,unm,usal;	
try {
		 fos=new FileOutputStream("PersonProps.properties");
		 myDbInfo=new Properties();		
		 System.out.print("Enter id");
		 uid=in.next();
		 myDbInfo.setProperty("userId" ,uid);
		 System.out.print("Enter Name");
		 unm=in.next();
		 myDbInfo.setProperty("userNm" ,unm);
		 System.out.print("Enter salary");
		 usal=in.next();
		 myDbInfo.setProperty("userSal" ,usal);
		 
		 myDbInfo.store(fos,"This is database info");
		 
		 System.out.println("Data written in file");
		 
  fis=new FileInputStream("PersonProps.properties");
				
			myDbInfo.load(fis);
			String u_id=myDbInfo.getProperty("userId");
			String u_nm=myDbInfo.getProperty("userNm");
			String u_sal=myDbInfo.getProperty("userSal");
			
			System.out.println("Credentials "+u_id+":"+u_nm+":"+u_sal);
				System.out.println("************");
			    Set<Object> ks=myDbInfo.keySet();
			    Collection<Object> cn=myDbInfo.values();
				Iterator it=ks.iterator();
				Iterator it_n=cn.iterator();
				while(it.hasNext())
				{
					System.out.println(it.next());
					System.out.println(it_n.next());
					
				}}
				
				catch (IOException e) {
					
					e.printStackTrace();
				}
				
		}
}
