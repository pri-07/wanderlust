import java.util.ArrayList;
	import java.util.Iterator;
import java.util.TreeSet;
public class TreeSetEmpDemo {


		public static void main(String[] args) {
			// TODO Auto-generated method stub

			
			
			TreeSet<Emp> empList =new TreeSet<Emp>();
			
	Emp e1=new Emp(111,"acfcf",44.0F);
	Emp e2=new Emp(222,"bcfcf",55.0F);
	Emp e3=new Emp(3333,"ccfcf",66.0F);
	Emp e4=new Emp(444,"ccfcf",77.0F);	
	empList.add(e1);
	empList.add(e2);
	empList.add(e3);
	empList.add(e4);


		Iterator<Emp> itEmp=empList.iterator();
		while(itEmp.hasNext())
		{
			System.out.println("....."+itEmp.next());
			
		}
		}

	}



