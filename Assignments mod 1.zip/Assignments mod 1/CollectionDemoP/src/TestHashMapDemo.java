import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
public class TestHashMapDemo {
public static void main(String args[])
{
	HashMap<Long,String> directory=new HashMap<Long,String>();
	directory.put(45454248L,"Divisha");
	directory.put(45454544L,"weeee");
	directory.put(7754248L,"heeeeee");
	directory.put(66454248L,"iiiiiiii");
	directory.put(88454248L,"Divisha");
	System.out.println(directory);
	
	System.out.println("Print ENTREIS");
	Set<Map.Entry<Long,String>> mapSet=directory.entrySet();
	Iterator<Map.Entry<Long,String>> it=mapSet.iterator();
	while(it.hasNext())
		
	{Map.Entry<Long,String> entry =it.next();
	System.out.println("Key  "+entry.getKey()+ "  Name  "+entry.getValue());
	}
	
	}
}
