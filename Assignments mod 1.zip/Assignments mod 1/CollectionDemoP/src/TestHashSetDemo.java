import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
public class TestHashSetDemo{
public static void main(String args[])
	{
		HashSet intSet=new HashSet(4); 
	
		Integer i1=new Integer(40);
	Integer i2=new Integer(10);
	Integer i3=new Integer(40);
	Integer i4=new Integer(30);
	
	
	intSet.add(i1);
	intSet.add(i2);
	intSet.add(i3);
	intSet.add(i4);
	System.out.println("Size  "+intSet.size());
	
	Iterator it=intSet.iterator();
	while(it.hasNext())
	{
		System.out.println("Entry:"+it.next());	}
	{
		
	}	
	
	}
}