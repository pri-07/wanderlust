	import java.util.HashMap;
	import java.util.Iterator;
	import java.util.Map;
	import java.util.Set;

public class TesthashMapDemoKey {


	public static void main(String args[])
	{
		HashMap<Long,String> directory=new HashMap<Long,String>();
		directory.put(45454248L,"Divisha");
		directory.put(45454544L,"weeee");
		directory.put(7754248L,"heeeeee");
		directory.put(66454248L,"iiiiiiii");
		directory.put(88454248L,"Divisha");
		System.out.println(directory);
		System.out.println("Print KEYS");
		Set<Long> kSet=directory.keySet();
		Iterator<Long> itk=kSet.iterator();
		while(itk.hasNext())
		{
			//Long key =itk.next();
		System.out.println("Key  "+itk.next());
		}
		
		}
	}
	

	
