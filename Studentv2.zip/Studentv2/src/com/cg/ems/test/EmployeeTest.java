package com.cg.ems.test;

import static org.junit.Assert.*;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;


import org.junit.Test;

public class EmployeeTest {
	@Test(expected=EmployeeException.class)
	public void test_ValidateName_null() throws EmployeeException{
		EmployeeService service=new EmployeeServiceImpl();
		service.validateName(null);		
	}
	
//	@Test
//	public void test_validateName_v1() throws PurchaseException{
//	
//		String name="Aete121";
//		PurchaseService service=new PurchaseServiceImpl();
//		boolean result= service.validateName(name);
//		Assert.assertEquals(false,result);
//	}
//	@Test
//	public void test_validateName_v2() throws PurchaseException{
//	
//		String name="Amita";
//		PurchaseService service=new PurchaseServiceImpl();
//		boolean result= service.validateName(name);
//		Assert.assertEquals(true,result);
//	}
//	@Test
//	public void test_validateName_v3() throws PurchaseException{
//	
//		String name="amita";
//		PurchaseService service=new PurchaseServiceImpl();
//		boolean result= service.validateName(name);
//		Assert.assertEquals(false,result);
//	}
//	

}




