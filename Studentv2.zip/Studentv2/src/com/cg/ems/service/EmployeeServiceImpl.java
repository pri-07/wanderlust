package com.cg.ems.service;



import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.dao.EmployeeDAO;
import com.cg.ems.dao.EmployeeDAOImpl;
import com.cg.ems.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	
	//To dao
	EmployeeDAO dao;
	public EmployeeServiceImpl()
	{
		dao=new EmployeeDAOImpl();
		
	}
	
	@Override
	public int addEmployee(Employee emp) {
		return dao.addEmployee(emp);
	}
	
	@Override
	public Employee displayEmployee(int empid) {
		return dao.displayEmployee(empid);
	}
	
	@Override
	public Employee updateEmployee(Employee emp) {
		return dao.updateEmployee(emp);
	}

	@Override
	public ArrayList<Employee> searchEmployee(String projname) {
		return dao.searchEmployee(projname);
	}

	
	//Validation
	@Override
	public Employee validateDetails(Employee emp) {
		if( (validateName(emp.getName())) && (validateProjname(emp.getProjname())) && (validateSalary(emp.getSalary())))
			return emp;
		else 
			return null;
	}

	@Override
	public boolean validateName(String name) {
		Pattern pat=Pattern.compile("[A-Z][a-z]{3,12}");
		Matcher mat=pat.matcher(name);
		return mat.matches();
		
	}

	@Override
	public boolean validateSalary(Double salary) {
		String sal=salary.toString();
		return (sal.matches("\\d{4,9}\\.\\d{0,4}"));
	}

	@Override
	public boolean validateProjname(String projname) {
		Pattern pat=Pattern.compile("[A-Z][a-z]{3,12}");
		Matcher mat=pat.matcher(projname);
		return mat.matches();
	
	}
	
}
	
	

	
	

