package com.cg.ems.service;


import java.util.ArrayList;

import com.cg.ems.dto.Employee;

public interface EmployeeService {
	
	public int addEmployee(Employee emp);
	public Employee displayEmployee(int empid);
	public Employee updateEmployee(Employee emp);
	public ArrayList<Employee> searchEmployee(String projname);
	
	public Employee validateDetails(Employee e);
	public boolean validateName(String name);
	public boolean validateSalary(Double salary);
	public boolean validateProjname(String projname);
	
	
}
