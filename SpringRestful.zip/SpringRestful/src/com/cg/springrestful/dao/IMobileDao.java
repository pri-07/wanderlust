package com.cg.springrestful.dao;

import java.util.List;

import com.cg.springrestful.dto.Mobile;

public interface IMobileDao {
	
	public List<Mobile> getAllData();

}
